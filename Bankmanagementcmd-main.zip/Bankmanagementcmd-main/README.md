# Bankmanagementcmd
bank management system in cmd
